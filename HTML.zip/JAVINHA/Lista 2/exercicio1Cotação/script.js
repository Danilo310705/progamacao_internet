let btCalcular = document.querySelector("#btCalcular");
let dolar = document.querySelector("#dolar");
let dolar1 = document.querySelector("#dolar1");
let dolar2 = document.querySelector("#dolar2");
let dolar3 = document.querySelector("#dolar3");
let dolar4 = document.querySelector("#dolar4");

function aumentos(){
    dolar1.textContent = Number(dolar.value) * 1.01;
    dolar2.textContent = Number(dolar.value) * 1.02;
    dolar3.textContent = Number(dolar.value) * 1.05;
    dolar4.textContent = Number(dolar.value) * 1.10;
}

btCalcular.onclick = function (){
    aumentos();
}