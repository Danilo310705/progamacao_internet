let pessoas = document.querySelector("#pessoas");
let btcalculo = document.querySelector("#btcalculo");
let valorOvo = document.querySelector("#valorOvo");
let valorQueijo = document.querySelector("#valorQueijo");

function ovosEQueijo(){
    valorOvo.textContent = Number(pessoas.value) * 2;
    valorQueijo.textContent = Number(pessoas.value) * 0.05 + "Kg" 
}

btcalculo.onclick = function (){
    ovosEQueijo()
}