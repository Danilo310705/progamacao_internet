refrigerante = document.querySelector("#refrigerante");
pedido = document.querySelector("#pedido");
btValor = document.querySelector("#btValor");
peperone = document.querySelector("#peperone");
queijos4 = document.querySelector("#queijos4");
frangoChedar = document.querySelector("#frangoChedar");
muitoQueijo = document.querySelector("#muitoQueijo");
pRatao = document.querySelector("#pRatao");
podrao = document.querySelector("#podrao");

function sabores(){
    
    let quantpepe;
    let quantqueijos4;
    let quantfrangoChedar;
    let quantmuitoQueijo;
    let quantpRatao;
    let quantpodrao;
    if(Number(peperone.value) > 0 && Number(peperone.value) <= 4){
        quantpepe = Number(peperone.value) + " de peperone";
    }else{
        quantpepe = "";
    }
    if(Number(queijos4.value) > 0 && Number(queijos4.value) <= 4){
        quantqueijos4 = Number(queijos4.value) + " de 4 queijos";
    }else{
        quantqueijos4 = "";
    }
    if(Number(frangoChedar.value) > 0 && Number(frangoChedar.value) <= 4){
        quantfrangoChedar = Number(frangoChedar.value) + " de Frango com Chedar";
    }else{
        quantfrangoChedar = "";
    }
    if(Number(muitoQueijo.value) > 0 && Number(muitoQueijo.value) <= 4){
        quantmuitoQueijo = Number(muitoQueijo.value) + " de 1000 Queijos";
    }else{
        quantmuitoQueijo = "";
    }
    if(Number(pRatao.value) > 0 && Number(pRatao.value) <= 4){
        quantpRatao = Number(pRatao.value) + " de Ratão";
    }else{
        quantpRatao = "";
    }
    if(Number(podrao.value) > 0 && Number(podrao.value) <= 4){
        quantpodrao = Number(podrao.value) + " de Podrao";
    }else{
        quantpodrao = "";
    }
    let retSabores = quantpepe +" "+ quantqueijos4 +" "+ quantfrangoChedar +" "+ quantmuitoQueijo +" "+ quantpRatao +" "+ quantpodrao;
    return retSabores;
}

function funcPedido(){

    let quantidfatias = Number(peperone.value) + Number(queijos4.value) + Number(frangoChedar.value) + Number(muitoQueijo.value) + Number(pRatao.value) + Number(podrao.value);
    let valorPizza = 0;
    let valorRefrigerante = 0;
    let quantpepe
    let quantqueijos4
    if (quantidfatias <= 0){
        valorPizza = 0;
    }else{
        if(quantidfatias == 1){
            valorPizza = 12;
            
        }else{
            if(quantidfatias == 2){
                valorPizza = 24;
            }else{
                if(quantidfatias == 3){
                    valorPizza = 36;
                }else{
                    if(quantidfatias == 4){
                        valorPizza = 48;
                    }else{
                        valorPizza = "Não existe fatias maiores que 4";
                    }
                }
            }
        }
    }
    valorRefrigerante = 7.00 * refrigerante.value;
    if(valorPizza == "Não existe fatias maiores que 4"){
        pedido.textContent = valorPizza + " e " + valorRefrigerante + " do refrigerante totalizando " + valorRefrigerante + " reais"+ sabores(); 
    }else{
        pedido.innerHTML = "O valor da pizza é de " + valorPizza + " e " + valorRefrigerante + " do refrigerante totalizando " + (valorPizza+valorRefrigerante) + " reais" + "<br>" + sabores();
    }
}



btValor.onclick = function(){
    funcPedido();
}