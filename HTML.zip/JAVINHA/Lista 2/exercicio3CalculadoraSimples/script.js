let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let btCalculo = document.querySelector("#btCalculo");
let resultadoSoma = document.querySelector("#resultadoSoma");
let resultadoSub = document.querySelector("#resultadoSub");
let resultadoMulti = document.querySelector("#resultadoMulti");
let resultadoDivis = document.querySelector("#resultadoDivis");

function calculo(){
    resultadoSoma.textContent = Number(numero1.value) + Number(numero2.value);
    resultadoSub.textContent = Number(numero1.value) - Number(numero2.value);
    resultadoMulti.textContent = Number(numero1.value) * Number(numero2.value);
    resultadoDivis.textContent = Number(numero1.value) / Number(numero2.value);
}

btCalculo.onclick = function(){
    calculo()
}