let quantPao = document.querySelector("#quantPao");
let quantBroa = document.querySelector("#quantBroa");
let btCalcular = document.querySelector("#btCalcular");
let resultVendas = document.querySelector("#resultVendas");
let resultPoupanca = document.querySelector("#resultPoupanca");

function calcular() {
    let valorPao = Number(quantPao.value) * 0.12;
    let valorBroa = Number(quantBroa.value) * 1.50;
    let totalVendas = valorPao + valorBroa;
    let totalPoupanca = totalVendas * 0.1;

    resultVendas.textContent = totalVendas;
    resultPoupanca.textContent = totalPoupanca;
}

btCalcular.onclick = function () {
    calcular();
}