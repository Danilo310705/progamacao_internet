let comprimento = document.querySelector("#comprimento");
let largura = document.querySelector("#largura");
let resultado = document.querySelector("#resultado");
let calcular = document.querySelector("#calcular");

function calcularArea() {
    let resposta 
    if(Number(comprimento.value) = Number(largura.value)){
        resposta = "A área do quadrado é " + + " m², não vendemos quadrados";
    }else{
        resposta = "A área do retângulo é " + + " m²";
    }
    resultado.textContent = resposta;
}

calcular.onclick = function (){
    calcularArea();
}