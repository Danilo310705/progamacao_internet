let posicao1X = document.querySelector("#posicao1X");
let posicao1Y = document.querySelector("#posicao1Y");
let posicao2X = document.querySelector("#posicao2X");
let posicao2Y = document.querySelector("#posicao2Y");
let resultado = document.querySelector("#resultado");
let btCalcular = document.querySelector("#btCalcular");

function calcularDistancia() {
    
    let x1 = Number(posicao1X.value);
    let y1 = Number(posicao1Y.value);
    let x2 = Number(posicao2X.value);
    let y2 = Number(posicao2Y.value);

    let distancia = ((( x2 - x1 )**2) + (( y2 - y1 )**2)) **0.5;
    resultado.textContent = distancia;
    
}
btCalcular.onclick = function() {
    calcularDistancia();
}