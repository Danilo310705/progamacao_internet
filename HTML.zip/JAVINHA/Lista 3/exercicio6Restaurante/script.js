let quilo = document.querySelector("#quilo");
let resultado = document.querySelector("#resultado");
let btCalcular = document.querySelector("#btCalcular");

function calcular() {
    let valorPagar = Number(quilo.value) * 12.00;
    resultado.textContent = "valor a ser pago: R$ " + valorPagar.toFixed(2);
}

btCalcular.onclick = function(){
    calcular();
}