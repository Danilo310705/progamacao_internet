let cavalos = document.querySelector("#cavalos");
let btCalculo = document.querySelector("#btCalculo");
let resultado = document.querySelector("#resultado");

function calcular() {
resultado.textContent = Number(cavalos.value) * 4;
}

btCalculo.onclick = function(){
    calcular();
}