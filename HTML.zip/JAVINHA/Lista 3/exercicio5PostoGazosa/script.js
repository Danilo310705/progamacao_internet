let precoCombust = document.querySelector("#precoCombust");
let valorCombust = document.querySelector("#valorCombust");
let btnCalcular = document.querySelector("#btnCalcular");
let resultado = document.querySelector("#resultado");

function calcularValor() {
    let quentCombust = Number(valorCombust.value) / Number(precoCombust.value) ;
    resultado.innerHTML = "foi colocado " + quentCombust + " litros de combustivel";
} 

btnCalcular.onclick = function() {
    calcularValor();
}
