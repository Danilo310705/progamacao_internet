let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularIdade() {
    let diasVividos = Number(idade.value) * 365;

    if(idade.value < 18){
        resultado.textContent = "Parabens " + nome.value + ", voce esta vivendo a" + diasVividos + ", parabens pelo easy mode."
    }else{
        resultado.textContent = "Parabens " + nome.value + ", voce esta sobrevivendo a" + diasVividos + ", boa sorte no hard mode."
    }
}
btCalcular.onclick = function() {
    calcularIdade();
}
