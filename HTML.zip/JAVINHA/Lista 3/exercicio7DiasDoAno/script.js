let dia = document.querySelector("#dia");
let mes = document.querySelector("#mes");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularDiasDoAno() {
    let diasNoMes = (30 * Number(mes.value)) - 30;
    resultado.textContent = diasNoMes + Number(dia.value);
}


btCalcular.onclick = function() {
    calcularDiasDoAno();
}