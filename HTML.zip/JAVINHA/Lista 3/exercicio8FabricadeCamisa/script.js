let quantidadeP = document.querySelector("#quantidadeP");
let resultadoP = document.querySelector("#resultadoP");
let quantidadeM = document.querySelector("#quantidadeM");
let resultadoM = document.querySelector("#resultadoM");
let quantidadeG = document.querySelector("#quantidadeG");
let resultadoG = document.querySelector("#resultadoG");
let resultadoTotal = document.querySelector("#resultadoTotal");
let btCalcular = document.querySelector("#btCalcular");

function calcularCamisas(){
    let totalP = Number(quantidadeP.value) * 10;
    let totalM = Number(quantidadeM.value) * 12;
    let totalG = Number(quantidadeG.value) * 15;

    resultadoP.innerHTML = "R$ " + totalP.toFixed(2);
    resultadoM.innerHTML = "R$ " + totalM.toFixed(2);
    resultadoG.innerHTML = "R$ " + totalG.toFixed(2);
    resultadoTotal.innerHTML = "R$ " + ( totalP + totalM + totalG ).toFixed(2);
}

btCalcular.onclick = function() {
    calcularCamisas();
}