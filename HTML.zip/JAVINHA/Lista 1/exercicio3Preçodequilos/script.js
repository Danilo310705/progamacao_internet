let peso = document.querySelector("#peso");
let valorQuilo = document.querySelector("#valorQuilo");
let precoFinal = document.querySelector("#precoFinal");
let btCalculo = document.querySelector("#btCalculo")

function calcularValorPorQuilo(){
    precoFinal.textContent = Number(peso.value) * Number(valorQuilo.value) + ",00"
}

btCalculo.onclick = function(){
    calcularValorPorQuilo();
}