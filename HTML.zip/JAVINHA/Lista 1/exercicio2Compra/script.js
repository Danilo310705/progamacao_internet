let valorReceber = document.querySelector("#valorReceber");
let valorAPagar = document.querySelector("#valorAPagar");
let valTroco = document.querySelector("#valTroco");
let btCalculo = document.querySelector("#btCalculo");

function calcularTroco(){
    let valorAdicionado = Number(valorReceber.value);
    let valorSubtraido = Number(valorAPagar.value);
    let valorTotal = valorAdicionado - valorSubtraido;
    //valTroco.textContent = valorTotal;
    if(valorAdicionado < valorSubtraido){
        valTroco.textContent = "Não é possível realizar a compra!";
    }else{
        valTroco.textContent = valorTotal;
    }
}
btCalculo.onclick = function(){
    calcularTroco();
}
