let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let btSoma = document.querySelector("#btSoma");
let resultado = document.querySelector("#resultado");

function resultadoSoma(){
    let valor1 = numero1.value;
    let valor2 = numero2.value;

    let soma = parseFloat(valor1) + parseFloat(valor2);

    resultado.textContent = soma;
}

btSoma.onclick = function(){
    resultadoSoma();
}
