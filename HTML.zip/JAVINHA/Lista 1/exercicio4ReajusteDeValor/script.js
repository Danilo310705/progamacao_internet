let numero = document.querySelector("#numero");
let valorFinal = document.querySelector("#valorFinal");
let btReajuste = document.querySelector("#btReajuste");

function calcularReajuste() {
    let valor = Number(numero.value);
    
   valorFinal.textContent = (valor * 0.01) + valor;
}

btReajuste.onclick = function(){
    calcularReajuste();
}