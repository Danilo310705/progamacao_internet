let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let brCalculo = document.querySelector("#brCalculo");
let resultado = document.querySelector("#resultado");

function calcular() {
    if (valor1.value > valor2.value) {
        resultado.textContent = "O maior valor é: " + valor1.value;
    }else{
        if(valor1.value < valor2.value){
            resultado.textContent = "O maior valor é: " + valor2.value;
        }else{
            resultado.textContent = "Os valores são iguais";
        }
    }

}

brCalculo.onclick = function() {
    calcular();

}