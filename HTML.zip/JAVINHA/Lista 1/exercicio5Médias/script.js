let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let numero3 = document.querySelector("#numero3");
let btCalcular = document.querySelector("#btCalcular");
let valorMediaArit = document.querySelector("#valorMediaArit");
let valorMediaPonderada = document.querySelector("#valorMediaPonderada");
let somaMedia = document.querySelector("#somaMedia");


function calcularMédias(){
    let MediaArit = (Number(numero1.value) + Number(numero2.value) + Number(numero3.value)) / 3;
    valorMediaArit.textContent = MediaArit
    let ponderada1 = Number(numero1.value) * 3;
    let ponderada2 = Number(numero2.value) * 2;
    let ponderada3 = Number(numero3.value) * 5;
    let resultadoPonderada = (ponderada1 + ponderada2 + ponderada3) / 10;
    valorMediaPonderada.textContent = resultadoPonderada;
    somaMedia.textContent = MediaArit + resultadoPonderada;
    mediaMedia.textContent = (MediaArit + resultadoPonderada) /2;
}

btCalcular.onclick = function(){
    calcularMédias();
}